package com.service;

import com.domain.User;

public interface UserService {

    public boolean save(User user);
    public boolean update(User user);

}
