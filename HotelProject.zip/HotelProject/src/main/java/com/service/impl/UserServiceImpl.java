package com.service.impl;

import com.dao.UserDao;
import com.domain.User;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

  @Override
    public boolean save(User user) {
        //userDao.save(user);
        return true;
    }

    @Override
    public boolean update(User user) {
        return false;
    }
}
