package com.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import javax.sql.DataSource;


public class JdbcConfig {

    @Value("${jdbc.driver}")
    private String driver;
    private String url;
    private String username;
    private String password;

    @Bean
    public DataSource dataSource(){
        return null;
    }
}
