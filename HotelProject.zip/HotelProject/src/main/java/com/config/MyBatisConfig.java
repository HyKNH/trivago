package com.config;

public class MyBatisConfig {


}
