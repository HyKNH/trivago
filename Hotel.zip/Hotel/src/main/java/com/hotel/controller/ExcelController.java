package com.hotel.controller;

import com.hotel.pojo.Home;
import com.hotel.pojo.Vip;
import com.hotel.service.HomeServiceImpl;
import com.hotel.service.VipServiceImpl;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

@Controller
@RequestMapping("/excel")
public class ExcelController {

    @Autowired
    HomeServiceImpl homeService;
    @Autowired
    VipServiceImpl vipService;

    @RequestMapping("/home")
    public void excel_home(HttpServletResponse response )throws IOException {

        response.setCharacterEncoding("UTF-8");
        List<Home> homeList=homeService.queryAllHome();
        //创建excel文件
        HSSFWorkbook wb = new HSSFWorkbook();
        //创建sheet页
        HSSFSheet sheet = wb.createSheet("Room Information");
        //创建标题行
        HSSFRow titleRow = sheet.createRow(0);
        titleRow.createCell(0).setCellValue("NO");
        titleRow.createCell(1).setCellValue("RoomId");
        titleRow.createCell(2).setCellValue("Type");
        titleRow.createCell(3).setCellValue("Price");
        titleRow.createCell(4).setCellValue("State");
        titleRow.createCell(5).setCellValue("Description");

        for(Home home:homeList){
            HSSFRow dataRow = sheet.createRow(sheet.getLastRowNum()+1);
            dataRow.createCell(0).setCellValue(home.getId());
            dataRow.createCell(1).setCellValue(home.getId());
            dataRow.createCell(2).setCellValue(home.getH_Type());
            dataRow.createCell(3).setCellValue(home.getPrice());
            dataRow.createCell(4).setCellValue(home.getState());
            dataRow.createCell(5).setCellValue(home.getText());
        }

        // 设置下载时客户端Excel的名称
        response.setContentType("application/octet-stream;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename="
                + new String("Room_Information".getBytes(),"iso-8859-1") + ".xls");

        OutputStream ouputStream = response.getOutputStream();
        wb.write(ouputStream);
        ouputStream.flush();
        ouputStream.close();

    }

    @RequestMapping("/vip")
    public void excel_vip(HttpServletResponse response )throws IOException {

        response.setCharacterEncoding("UTF-8");
        List<Vip> vipList=vipService.queryAllVip();
        //创建excel文件
        HSSFWorkbook wb = new HSSFWorkbook();
        //创建sheet页
        HSSFSheet sheet = wb.createSheet("VIP Information");
        //创建标题行
        HSSFRow titleRow = sheet.createRow(0);
        titleRow.createCell(0).setCellValue("NO.");
        titleRow.createCell(1).setCellValue("Name");
        titleRow.createCell(2).setCellValue("Sex");
        titleRow.createCell(3).setCellValue("Email");
        titleRow.createCell(4).setCellValue("Phone");
        titleRow.createCell(5).setCellValue("Level");
        titleRow.createCell(6).setCellValue("StartTime");
        titleRow.createCell(7).setCellValue("EndTime");

        for(Vip vip:vipList){
            HSSFRow dataRow = sheet.createRow(sheet.getLastRowNum()+1);
            dataRow.createCell(0).setCellValue(vip.getId());
            dataRow.createCell(1).setCellValue(vip.getName());
            dataRow.createCell(2).setCellValue(vip.getSex());
            dataRow.createCell(3).setCellValue(vip.getEmail());
            dataRow.createCell(4).setCellValue(vip.getPhone());
            dataRow.createCell(5).setCellValue(vip.getV_Type());
            dataRow.createCell(6).setCellValue(vip.getStartTime());
            dataRow.createCell(7).setCellValue(vip.getEndTime());
        }

        // 设置下载时客户端Excel的名称
        response.setContentType("application/octet-stream;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename="
                + new String("Vip_Information".getBytes(),"iso-8859-1") + ".xls");

        OutputStream ouputStream = response.getOutputStream();
        wb.write(ouputStream);
        ouputStream.flush();
        ouputStream.close();

    }

}
