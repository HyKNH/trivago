package com.hotel.controller;

import com.hotel.pojo.Home;
import com.hotel.pojo.Vip;
import com.hotel.service.HomeServiceImpl;
import com.hotel.service.VipServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * UserVip controller
 * @since jdk1.8
 * @version 1.0
 * @author Yu Long
 * **/

@Controller
@RequestMapping("/vip")
public class VipController {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private static final String SESSION_USER = "LOGINUSER";
    private static final String DEFAULT_VIP_NAME = "VIPCustomer";
    private static final String DEFAULT_VIP_SEX = "Male";
    private static final String DEFAULT_VIP_TYPE = "Junior Vip";

    @Autowired
    HttpSession session;
    @Autowired
    VipServiceImpl vipService;
    @Autowired
    HomeServiceImpl homeService;


    /**
     * Add VIP user function and input information
     * Pass in the user information field and store it in the database according to sql
     * @param vip
     * @return result
     * **/
    @RequestMapping("/add")
    public ModelAndView add(Vip vip) {
        ModelAndView mv = new ModelAndView();
        Random rand = new Random();
        int randomNumber = rand.nextInt(1000)+1;
        vip.setId(randomNumber);
        vipService.addVip(vip);
        homeService.updateH_TypeById(vip.getRoomid());
        mv.setViewName("suc_v");
        return mv;
    }

    /**
     * Delete by VIP user id
     * @param id
     * @return result
     * **/
    @RequestMapping("/delete")
    public String delete(int id) {
        vipService.deleteVipById(id);
        return "redirect:/vip/list";
    }

    /**
     * Query all VIP user information, return to list
     * @return viplist
     *
     * **/
    @RequestMapping("/list")
    public ModelAndView list() {
        ModelAndView mv = new ModelAndView();
        List<Vip> vipList = vipService.queryAllVip();
        mv.addObject("list", vipList);
        mv.setViewName("vip_list");
        return mv;
    }

    /**
     * Modify user information according to vip user id
     * After modification, pass in data and update the database
     * @param id
     * @return result
     *
     * **/
    @RequestMapping("/update1")
    public ModelAndView update1(int id) {
        ModelAndView mv = new ModelAndView();
        Vip vip = vipService.queryVipById(id);
        mv.addObject("v", vip);
        mv.setViewName("vip_update");
        return mv;
    }
    @RequestMapping("/cancel")
    public ModelAndView cancel(String id) {
        ModelAndView mv = new ModelAndView();
        homeService.cancelById(id);
        mv.setViewName("suc");
        return mv;
    }


    @RequestMapping("/guests_add")
    public ModelAndView guests_add(Integer id, Integer type) {
        ModelAndView mv = new ModelAndView();
        mv.addObject("roomid", id);
        mv.addObject("type", type);
        mv.setViewName("guests_add");
        return mv;
    }

/*
    @RequestMapping("/update2")
    public String update2(Vip v) {
        vipService.updateVipById(v);
        return ("redirect:/vip/list");
    }*/

    /**
     * Query user information based on VIP user's mobile phone number
     * @param findByPhone
     * @return viplist
     *
     * **/
    @RequestMapping("/find")
    public ModelAndView find(String findByPhone) {
        ModelAndView mv = new ModelAndView();
        Vip vip = vipService.queryVipByPhone(findByPhone);
        List<Vip> vipList = new ArrayList<Vip>();
        vipList.add(vip);
        if (vip == null) {
            vipList = vipService.queryAllVip();
            mv.addObject("verror", "No results found");
        }
        mv.addObject("list", vipList);
        mv.setViewName("vip_list");
        return mv;
    }

    /**
     * The administrator enters the account and password to enter the system for operation
     * Query the corresponding user account and password in the database to verify whether they match
     * @param password
     * @param username
     * @return result
     * @throws Exception
     *
     * **/
    @RequestMapping("/login")
    public ModelAndView login(String username, String password) throws Exception{
        ModelAndView mv = new ModelAndView();
        try {
            Vip vip = vipService.findByLogin(username, password);
            if (vip != null) {
              /*  if (vip.getPassword().equals(password)) {
                    session.setAttribute(SESSION_USER, vip);
                    mv.setViewName("vip/index");
                    return mv;
                }*/

                mv.setViewName("vip/index");
                return mv;
            }
            mv.setViewName("vip/index");
           // mv.addObject("result", "wrong password");
          //  mv.setViewName("vip/error");
            return mv;
        } catch (Exception e) {
            e.printStackTrace();
            mv.addObject("result", "System abnormality");
            mv.setViewName("vip/error");
        }
        return mv;
    }

    /**
     * The administrator queries information based on the room number
     * @param findByNum
     * @return homelist
     *
     * **/
    @RequestMapping("/home/find")
    public ModelAndView homeFind(int findByNum) {
        ModelAndView mv = new ModelAndView();
        Home home = homeService.queryHomeByNum(findByNum);
        List<Home> homeList = new ArrayList<Home>();
        homeList.add(home);
        if (home == null) {
            homeList = homeService.queryAllHome();
            mv.addObject("error", "No results found");
        }
        mv.addObject("list", homeList);
        mv.setViewName("vip/home_list");
        return mv;
    }

    /**
     * Make reservations based on room numbers
     * Check the room status and verify whether it can be booked
     * @param id
     * @return
     * @throws Exception
     *
     * **/


    /**
     * Query user's room reservation information based on room number
     * @param id
     * @return roomlist
     * **/
    @RequestMapping("/home/show")
    public ModelAndView homeShow(Integer id) {
        ModelAndView mv = new ModelAndView();
        Home home = homeService.queryHomeById(id);
        mv.addObject("home", home);
        mv.setViewName("vip/home_show");
        return mv;
    }

    /**
     * Register as a VIP user and enter information
     * @param vip
     * @return result
     *
     * **/
    @RequestMapping("/register")
    public ModelAndView register(Vip vip) {
        ModelAndView mv = new ModelAndView();
        if (StringUtils.isBlank(vip.getAccount())) {
            mv.addObject("result", "Account cannot be empty");
            mv.setViewName("vip/error");
            return mv;
        }
        if (StringUtils.isBlank(vip.getPassword())) {
            mv.addObject("result", "Password cannot be empty");
            mv.setViewName("vip/error");
            return mv;
        }
        if (!vip.getPassword().equals(vip.getConfirmPassword())) {
            mv.addObject("result", "Passwords do not match");
            mv.setViewName("vip/error");
            return mv;
        }
        Vip existVip = vipService.queryVipByAccount(vip.getAccount());
        if (existVip != null) {
            mv.addObject("result", "The account already exists");
            mv.setViewName("vip/error");
            return mv;
        }
        vip.setName(DEFAULT_VIP_NAME);
        vip.setSex(DEFAULT_VIP_SEX);
        vip.setEmail("0");
        vip.setPhone(0);
        vip.setV_Type(DEFAULT_VIP_TYPE);
        vip.setStartTime(sdf.format(new Date()));
        Calendar instance = Calendar.getInstance();
        instance.add(Calendar.YEAR, 1);
        vip.setEndTime(sdf.format(instance.getTime()));
        vipService.addVip(vip);
        mv.addObject("url", "/vip");
        mv.setViewName("vip/suc");
        return mv;
    }
}

