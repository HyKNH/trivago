package com.hotel.controller;

import com.hotel.pojo.Home;
import com.hotel.service.HomeServiceImpl;
import com.hotel.service.VipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/home")

public class HomeController {

    @Autowired
    HomeServiceImpl homeService;
    @Autowired
    VipService vipService;


    @RequestMapping("/add")
    public String add(Home home, Model model) throws IOException {

        String sqlPath = null;
        //定义文件保存的本地路径
        String localPath = "C:\\LY\\tools\\eclipse\\workSpace\\Hotel\\src\\main\\webapp\\WEB-INF\\views\\static\\admin\\img\\";
        //定义 文件名
        String filename = null;
        if (!home.getFile().isEmpty()) {
            //生成uuid作为文件名称
            String uuid = UUID.randomUUID().toString().replaceAll("-", "");
            //获得文件类型（可以判断如果不是图片，禁止上传）
            String contentType = home.getFile().getContentType();
            //获得文件后缀名
            String suffixName = contentType.substring(contentType.indexOf("/") + 1);
            //得到 文件名
            filename = "room" + home.getId() + "." + "jpg";
            System.out.println(filename);
            //文件保存路径
            home.getFile().transferTo(new File(localPath + filename));
        }
        //把图片的相对路径保存至数据库
        sqlPath =filename;
        System.out.println(sqlPath);
        home.setImg(sqlPath);

        homeService.addHome(home);
        model.addAttribute("home", home);
        return "home_show";
    }

    @RequestMapping("/delete")
    public ModelAndView delete(Integer id) {
        ModelAndView mv = new ModelAndView();
        homeService.deleteHomeById(id);
        mv.addObject("url", "/home/list");
        mv.setViewName("suc");
        return mv;
    }

    @RequestMapping("/list")
    public ModelAndView list() {
        ModelAndView mv = new ModelAndView();
        List<Home> homeList = homeService.queryAllHome();
       /* for (Home home : homeList) {
            ArrayList<Appointment> appointments = appointmentService.queryAll(null, home.getId());
            if (appointments != null && !appointments.isEmpty()) {
                Appointment appointment = appointments.get(0);
                Vip vip = vipService.queryVipById(appointment.getVip_Id());
                home.setAppointmentName(vip.getName());
            }
            ArrayList<Guests> guests = guestsService.queryAllGuests();
            for (Guests guest : guests) {
                if (home.getNum()==guest.getNum()) {
                    home.setAppointmentName(guest.getName());
                    home.setState(HomeState.OCCUPIED.getState());
                    break;
                }
            }
        }*/
        mv.addObject("list", homeList);
        mv.setViewName("home_list");
        return mv;
    }

    @RequestMapping("/update1")
    public ModelAndView update1(Integer id) {
        ModelAndView mv = new ModelAndView();
        Home home = homeService.queryHomeById(id);
        mv.addObject("h", home);
        mv.setViewName("home_update");
        return mv;
    }


    @RequestMapping("/show")
    public ModelAndView show(Integer id) {
        ModelAndView mv = new ModelAndView();
        Home home = homeService.queryHomeById(id);
        mv.addObject("home", home);
        mv.setViewName("home_show");
        return mv;
    }


    @RequestMapping("/home_add")
    public String home(){
        return "home_add";
    }

    @RequestMapping("/find")
    public ModelAndView find(int findByNum) {
        ModelAndView mv = new ModelAndView();
        Home home = homeService.queryHomeByNum(findByNum);
        List<Home> homeList = new ArrayList<Home>();
        homeList.add(home);
        if (home == null) {
            homeList = homeService.queryAllHome();
            mv.addObject("error", "No results found");
        }
        mv.addObject("list", homeList);
        mv.setViewName("home_list");
        return mv;
    }

}
